-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Окт 26 2020 г., 07:06
-- Версия сервера: 5.6.41
-- Версия PHP: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `mvc`
--

-- --------------------------------------------------------

--
-- Структура таблицы `portfolio`
--

CREATE TABLE `portfolio` (
  `id` int(11) NOT NULL,
  `year` year(4) NOT NULL,
  `site` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `portfolio`
--

INSERT INTO `portfolio` (`id`, `year`, `site`, `description`) VALUES
(1, 2012, 'http://DunkelBeer.ru', 'Промо-сайт темного пива Dunkel от немецкого производителя Löwenbraü выпускаемого в России пивоваренной компанией \"CАН ИнБев\".'),
(2, 2012, 'http://ZopoMobile.ru', 'Русскоязычный каталог китайских телефонов компании Zopo на базе Android OS и аксессуаров к ним.'),
(3, 0000, '', ''),
(4, 0000, 'Array', 'Array'),
(5, 2000, 'test', 'test'),
(6, 2000, 'test', 'test'),
(7, 2000, 'test', 'test'),
(8, 2012, 'http://ZopoMobile.ru', 'Русскоязычный каталог китайских телефонов компании Zopo на базе Android OS и аксессуаров к ним.'),
(9, 2012, 'http://GeekWear.ru', 'Интернет-магазин брендовой одежды для гиков.'),
(10, 2011, 'http://TompsonTatoo.ru', 'Персональный сайт-блог художника-татуировщика Алексея Томпсона из Санкт-Петербурга.'),
(11, 2011, 'http://TiltPeople.ru', 'Сайт сообщества фотографов в стиле Tilt Shif.'),
(12, 2011, 'http://AbsurdGames.ru', 'Страничка российской команды разработчиков независимых игр с необычной физикой и сюрреалистической графикой.');

-- --------------------------------------------------------

--
-- Структура таблицы `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `service` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `services`
--

INSERT INTO `services` (`id`, `service`, `description`) VALUES
(1, 'Разработка программного обеспечения на заказ', 'Мы разрабатываем программное обеспечение, в том числе проводим работы по проектированию, разработке, тестированию и внедрению программных продуктов.'),
(2, 'Сопровождение программных продуктов и техническая поддержка', 'Наша комманда осуществляет техническую поддержку и развитие программных продуктов, как собственного производства, так и сторонних организаций.'),
(3, 'Независимое тестирование программного обеспечения', 'Сотрудники нашей компании профессионально выполнят тестирование новых версий программных продуктов, включая функциональное, нагрузочное и модульное тестирование. Независимое тестирование позволит определить работоспособность программного продукта и выявить критические точки при большой нагрузке.'),
(4, 'Документирование', 'Мы также выполним работы, связанные с разработкой и поддержкой документации на программное обеспечение, включая технический проект, руководства пользователя и т.п.'),
(5, 'Аутсорсинг разработки и поддержки программного обеспечения', 'Наша компания возьмет на себя выполнение процессов по разработке и сопровождению программного обеспечения. Это позволит вам сосредоточить внимание на развитии бизнеса и укреплении отношений с клиентами.');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `portfolio`
--
ALTER TABLE `portfolio`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `portfolio`
--
ALTER TABLE `portfolio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT для таблицы `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
