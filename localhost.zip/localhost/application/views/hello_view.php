<h1>Hello <?=$name ?> </h1>
<p><?=$time ?></p>

<? foreach ($users as $user): ?>
    <p><?=$user?></p>
<? endforeach; ?>