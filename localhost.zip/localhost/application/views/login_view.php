<form action="">

    <label for="login">Логин</label>
    <input type="text" name="login" id="login">

    <label for="password">Пароль</label>
    <input type="text" name="password" id="password">

    <input type="submit" value="Войти">

</form>