<h1>Услуги</h1>

Компания <a href="/">ОЛОЛОША TEAM</a> оказывает следующие услуги:

<p>
    <ul>

<?php

foreach($data as $row)
{
    echo '
<li>'.$row['service'].'</li>
<p>'.$row['description'].'</p>
';
}

?>
    </ul>
</p>
