<?php
class Controller_Test extends Controller
{
    public function action_index()
    {
        ;
        $this->view->generate('hello_view.php', 'template_view.php',
            [
                'name' => 'khpk123',
                'time' => date('Y:m:d'),
                'users' =>[
                    'user1',
                    'user2',
                    'user3',
                    'user4',
                    'user5',
                ]
            ]
        );
    }
    public function action_khpk()
    {
        $this->view->generate('khpk_view.php', 'template_view.php');
    }
}