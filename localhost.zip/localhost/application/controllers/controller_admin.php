<?php

class Controller_Admin extends Controller
{
	
	function action_index()
	{
        echo 'admin panel';
	}

    public function action_login_page()
    {
        $this->view->generate('login_view.php', 'template_view.php');
	}

}
