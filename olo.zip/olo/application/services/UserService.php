<?php

class UserService
{

	private $adminPassword = '123';

	private $adminLogin = 'qwe';
	
	public function login($login, $password)
	{
	    if($login == $this->adminLogin && $password == $this->adminPassword){
	        $_SESSION['admin'] = true;
            return true;
        }else{
            return false;
        }
	}

	public function logout()
	{
        session_destroy();
	}

	public function isAuth()
	{
        return !!$_SESSION['admin'];
	}

}