<?php

require_once $_SERVER['DOCUMENT_ROOT'].'/application/middleware/AdminMiddleware.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/application/models/model_portfolio.php';

class Controller_Admin_Portfolio extends Controller
{

    function __construct()
    {
        $this->middleware[] = new AdminMiddleware();
        parent::__construct();
        $this->model = new Model_Portfolio();
    }

    function action_index()
    {
        $data = $this->model->get_data();
        $this->view->generate('admin_portfolio_view.php', 'template_view.php', $data);;
    }

    function action_create()
    {
        $this->view->generate('admin_portfolio_create_view.php', 'template_view.php');
    }

    public function action_store()
    {
        $model = new Model_Portfolio();
        $model->insert([
            'year' => $_POST['year'],
            'site' => $_POST['site'],
            'description' => $_POST['description'],

        ]);
    }

}