<h1>Форма записи</h1>

<form action="/admin_portfolio/store" method="post">

    <label for="year">Год</label><br>
    <input type="text" name="year" id="year"><br>

    <label for="site">Сайт</label><br>
    <input type="text" name="site" id="site"><br>

    <label for="description">Описание</label><br>
    <textarea name="description" id="description" cols="30" rows="10"></textarea><br>

    <input type="submit" value="Добавить в портфолио">
</form>